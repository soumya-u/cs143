SELECT COUNT(DISTINCT aff_city, aff_country)
FROM Affiliations
WHERE aff_name="University of California";