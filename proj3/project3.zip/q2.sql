SELECT DISTINCT aff_country
FROM Affiliations
WHERE aff_name="CERN";