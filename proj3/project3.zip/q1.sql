SELECT id
FROM Person
WHERE givenName="Marie" AND familyName="Curie";